import GroceryList from "./components/GroceryList.jsx";
 
import "bootstrap/dist/css/bootstrap.css"
function App() {
  return (
      <GroceryList/>
  );
}
 
export default App